<?php
define('DEFAULT_VIEW', 'home');//set this to any page to be the default home page
define('BASE_URL', 'http://corsair.cs.iupui.edu:23631/a3/');

//database info
define('DB_HOST', 'localhost');
define('DB_USER', 'asmote');
define('DB_PASS', 'robsclass');
define('DB_NAME', 'asmote_db');
