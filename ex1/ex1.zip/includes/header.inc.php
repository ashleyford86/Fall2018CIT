<?php
ini_set('display_errors', 'On');
error_reporting('E_All');
?>
<!DOCTYPE>
<html>
<head>

<title>Ex 1 </title>

</head>

<body>

		<h1>
			Header

		</h1>
