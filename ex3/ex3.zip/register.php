<!DOCTYPE html>
<html>
<head>
    <title>Ashley Ford's Ex 3 </title>
</head>
<body>

<form action="results.php" id= "registration_form" class="registration_form" method="post">

<div>
<label for="firstname" id="firstname">*First Name:</label>
<input type="text" name="firstname" id="firstname" required />
</div>

<div>
<label for="lastname" id="lastname">*Last Name:</label>
<input type="text" name="lastname" id="lastname" required />
</div>

<div>
<label for="email" id="email">*Email:</label>
<input type="email" name="email" id="email" required />
</div>

<div>
<input type="submit" name="submitButton" class="button" value="Submit" />
</div>
</form>
</body>

</body>
</html>
