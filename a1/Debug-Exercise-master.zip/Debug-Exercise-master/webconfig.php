<?php

define('ABSOLUTE_PATH', '/home/asmote/htdocs/a1/Debug-Exercise-master');
define('URL_ROOT', 'http://corsair.cs.iupui.edu:23631/a1/Debug-Exercise-master/');

//added a closing php tag and added the right path/url root
?>
